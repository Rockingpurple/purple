# Web-Development 
<h1>Links for all my Web-Development Projects</h1>

<ul>
<li>https://swapnamoy-b.github.io/CV/ --- My CV 📄(Work in progress)</li>
<li>https://swapnamoy-b.github.io/Web-Development/TinDog/index.html  --- Tindog Website 🐶</li>  
<li>https://swapnamoy-b.github.io/Web-Development/Drum-Kit/index.html --- Play Drums here 🥁</li>
<li>https://swapnamoy-b.github.io/Web-Development/Dicee-Game/dicee.html --- Dicee Game 🎲 (Refresh website to play)</li> 
<li>https://swapnamoy-b.github.io/Web-Development/Simon-Game/index.html --- Simon Game 🎨 (Remember the color patterns)</li>
<li>https://aqueous-thicket-02608.herokuapp.com/ --- My NewsLetter Website ✍️ (Signup Now !!!) </li>
</ul>
